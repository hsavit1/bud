//
//  RootViewController.h
//  TDBadgedTableCell
//
//  Created by Tim on [Dec 30].
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import "TDBadgedCell.h"

@interface RootViewController : UITableViewController {
	NSArray *contents;
}

@end
